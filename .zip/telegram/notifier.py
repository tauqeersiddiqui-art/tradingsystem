# telegram/notifier.py
# Full control interface: persistent dual dashboards, trade confirmation, text commands.
#
# Two edit-in-place Telegram messages:
#   1. "AI ENGINE" — ML bias, technicals, decision reasoning, expectancy
#   2. "LIVE STATUS" — current position, trailing SL, market internals
#
# Message IDs are persisted to .telegram_state.json so they survive restarts
# and the same two messages are always edited in place (never new messages).

import os
import json
import logging
import time
import requests
from dotenv import load_dotenv

_log = logging.getLogger("tg.notifier")

PROJECT_ROOT = os.getcwd()
load_dotenv(os.path.join(PROJECT_ROOT, ".env"), override=True)

BOT_TOKEN          = os.getenv("TELEGRAM_BOT_TOKEN",  "").strip()
BOT_CHAT_ID        = os.getenv("TELEGRAM_BOT_CHAT_ID","").strip()
CHANNEL_ID         = os.getenv("TELEGRAM_CHANNEL_ID", "").strip()
AUTHORIZED_USER_ID = os.getenv("TELEGRAM_ADMIN_ID",   "").strip()

if not BOT_TOKEN:          raise RuntimeError("TELEGRAM_BOT_TOKEN missing")
if not BOT_CHAT_ID:        raise RuntimeError("TELEGRAM_BOT_CHAT_ID missing")
if not CHANNEL_ID:         raise RuntimeError("TELEGRAM_CHANNEL_ID missing")
if not AUTHORIZED_USER_ID: raise RuntimeError("TELEGRAM_ADMIN_ID missing")

API_URL             = f"https://api.telegram.org/bot{BOT_TOKEN}"
SEND_URL            = f"{API_URL}/sendMessage"
EDIT_MESSAGE_URL    = f"{API_URL}/editMessageText"
EDIT_MARKUP_URL     = f"{API_URL}/editMessageReplyMarkup"
GET_UPDATES_URL     = f"{API_URL}/getUpdates"
ANSWER_CALLBACK_URL = f"{API_URL}/answerCallbackQuery"

_STATE_FILE = os.path.join(PROJECT_ROOT, ".telegram_state.json")

# ─────────────────────────────────────────────────────────────────────
# SHARED STATE  (read by master_runner every cycle)
# ─────────────────────────────────────────────────────────────────────
MANUAL_EXIT_REQUESTED = False
ENGINE_PAUSED         = False
ENGINE_STOP_REQUESTED = False
CE_THRESHOLD_OVERRIDE = None
PE_THRESHOLD_OVERRIDE = None

_pending_confirm_id   = None
_pending_confirm_resp = None

# ─────────────────────────────────────────────────────────────────────
# BACKGROUND TELEGRAM THREAD
# Telegram I/O runs in a daemon thread with a queue.
# Engine loop calls are non-blocking — never stall trading.
# ─────────────────────────────────────────────────────────────────────
import queue
import threading

_tg_queue   = queue.Queue(maxsize=20)   # capped — drop if full (old data useless)
_poll_interval     = 3.0   # poll getUpdates every 3s when healthy
_poll_interval_max = 60.0  # back off to 60s after consecutive failures
_last_poll_ts      = 0.0
_poll_fail_count   = 0

def _tg_worker():
    """Background thread: drains the send queue and polls commands every 3s."""
    global _last_poll_ts, _poll_fail_count
    current_interval = _poll_interval
    while True:
        try:
            # Drain all pending sends first (non-blocking)
            while True:
                try:
                    fn, args, kwargs = _tg_queue.get_nowait()
                    fn(*args, **kwargs)
                    _tg_queue.task_done()
                except queue.Empty:
                    break
                except Exception as e:
                    _log.warning("[TG-thread] send error: %s", e)

            # Poll commands with exponential backoff on failure
            now = time.time()
            if now - _last_poll_ts >= current_interval:
                _last_poll_ts = now
                before = _poll_fail_count
                _poll_commands_internal()
                if _poll_fail_count > before:
                    # failure — back off (double interval, cap at max)
                    current_interval = min(current_interval * 2, _poll_interval_max)
                else:
                    # success — reset to normal interval
                    current_interval = _poll_interval

        except Exception as e:
            _log.warning("[TG-thread] worker error: %s", e)

        time.sleep(0.5)

_tg_thread = None

def _ensure_thread():
    global _tg_thread
    if _tg_thread is None or not _tg_thread.is_alive():
        _tg_thread = threading.Thread(target=_tg_worker, daemon=True)
        _tg_thread.start()


def _tg_enqueue(fn, *args, **kwargs):
    """Non-blocking enqueue. Drops silently if queue is full (stale data)."""
    _ensure_thread()
    try:
        _tg_queue.put_nowait((fn, args, kwargs))
    except queue.Full:
        pass

# ─────────────────────────────────────────────────────────────────────
# PERSISTENT MESSAGE IDs  — survives process restarts
# ─────────────────────────────────────────────────────────────────────
_engine_msg_id = None   # "AI ENGINE" dashboard
_market_msg_id = None   # "LIVE STATUS" dashboard
_trade_msg_id  = None   # current trade entry message (EXIT button)
_scalp_msg_id  = None   # current scalp entry message (no button)

_last_update_id = None
_last_edited    = {}    # message_id → last text (per-slot dedup)
_EDIT_GONE      = "GONE"


def _load_state():
    global _engine_msg_id, _market_msg_id
    try:
        with open(_STATE_FILE) as f:
            d = json.load(f)
        _engine_msg_id = d.get("engine")
        _market_msg_id = d.get("market")
    except Exception:
        pass


def _save_state():
    try:
        with open(_STATE_FILE, "w") as f:
            json.dump({"engine": _engine_msg_id, "market": _market_msg_id}, f)
    except Exception:
        pass


_load_state()   # restore IDs from previous session on import


# ─────────────────────────────────────────────────────────────────────
# LOW-LEVEL HELPERS
# ─────────────────────────────────────────────────────────────────────

def _send(chat_id, text, parse_mode="HTML", reply_markup=None, disable_web_page_preview=True):
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": parse_mode,
        "disable_web_page_preview": disable_web_page_preview,
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    try:
        r = requests.post(SEND_URL, json=payload, timeout=10)
        d = r.json()
        if not d.get("ok"):
            _log.warning("[TG] Send error: %s", d)
            return None
        return d.get("result")
    except Exception as e:
        _log.warning("[TG] Send exception: %s", e)
        return None


def _edit(message_id, text, parse_mode="HTML"):
    """Edit a message. Returns True, False for transient errors, or _EDIT_GONE."""
    if _last_edited.get(message_id) == text:
        return True
    try:
        r = requests.post(EDIT_MESSAGE_URL, json={
            "chat_id": BOT_CHAT_ID,
            "message_id": message_id,
            "text": text,
            "parse_mode": parse_mode,
            "disable_web_page_preview": True,
        }, timeout=10)
        d = r.json()
        if d.get("ok"):
            _last_edited[message_id] = text
            return True

        desc = str(d.get("description", "")).lower()
        if "message is not modified" in desc:
            _last_edited[message_id] = text
            return True

        if any(phrase in desc for phrase in (
            "message to edit not found",
            "message can't be edited",
            "message_id_invalid",
            "chat not found",
        )):
            _log.warning("[TG] Edit target gone: %s", d)
            return _EDIT_GONE

        _log.warning("[TG] Edit error: %s", d)
        return False
    except Exception as e:
        _log.warning("[TG] Edit exception: %s", e)
        return False


def _answer_cb(callback_id, text=""):
    try:
        requests.post(ANSWER_CALLBACK_URL,
                      json={"callback_query_id": callback_id, "text": text},
                      timeout=5)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────
# PUBLIC SENDERS
# ─────────────────────────────────────────────────────────────────────

def send_bot(message, parse_mode="HTML"):
    _tg_enqueue(_send, BOT_CHAT_ID, message, parse_mode=parse_mode)


def send_trade_channel(message):
    _tg_enqueue(_send, CHANNEL_ID, message, parse_mode="HTML")


# ─────────────────────────────────────────────────────────────────────
# DUAL DASHBOARD  — two persistent edit-in-place messages
# ─────────────────────────────────────────────────────────────────────

def _do_send_or_edit_engine(text: str):
    """Actual send/edit — runs inside background thread."""
    global _engine_msg_id
    if _engine_msg_id is None:
        result = _send(BOT_CHAT_ID, text)
        if result:
            _engine_msg_id = result["message_id"]
            _save_state()
    else:
        ok = _edit(_engine_msg_id, text)
        if ok == _EDIT_GONE:
            old_id = _engine_msg_id
            _engine_msg_id = None
            _last_edited.pop(old_id, None)
            _save_state()
            _do_send_or_edit_engine(text)


def _do_send_or_edit_market(text: str, reply_markup=None):
    """Actual send/edit — runs inside background thread."""
    global _market_msg_id
    if _market_msg_id is None:
        result = _send(BOT_CHAT_ID, text, reply_markup=reply_markup)
        if result:
            _market_msg_id = result["message_id"]
            _save_state()
    else:
        ok = _edit_with_markup(_market_msg_id, text, reply_markup)
        if ok == _EDIT_GONE:
            old_id = _market_msg_id
            _market_msg_id = None
            _last_edited.pop(old_id, None)
            _save_state()
            _do_send_or_edit_market(text, reply_markup)


def send_or_edit_engine_dashboard(text: str):
    """Non-blocking enqueue — returns instantly, thread does the actual I/O."""
    _tg_enqueue(_do_send_or_edit_engine, text)


def send_or_edit_market_dashboard(text: str, reply_markup=None):
    """Non-blocking enqueue — returns instantly, thread does the actual I/O."""
    _tg_enqueue(_do_send_or_edit_market, text, reply_markup)


def _edit_with_markup(message_id, text, reply_markup=None):
    if _last_edited.get(message_id) == text and not reply_markup:
        return True
    try:
        payload = {
            "chat_id": BOT_CHAT_ID,
            "message_id": message_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }
        if reply_markup:
            payload["reply_markup"] = reply_markup
        r = requests.post(EDIT_MESSAGE_URL, json=payload, timeout=10)
        d = r.json()
        if d.get("ok"):
            _last_edited[message_id] = text
            return True

        desc = str(d.get("description", "")).lower()
        if "message is not modified" in desc:
            _last_edited[message_id] = text
            return True

        if any(phrase in desc for phrase in (
            "message to edit not found",
            "message can't be edited",
            "message_id_invalid",
            "chat not found",
        )):
            _log.warning("[TG] Edit target gone: %s", d)
            return _EDIT_GONE

        _log.warning("[TG] Market edit error: %s", d)
        return False
    except Exception as e:
        _log.warning("[TG] Market edit exception: %s", e)
        return False


# Keep old single-dashboard name as alias for backward compat
def send_or_edit_dashboard(text: str, parse_mode: str = "HTML"):
    send_or_edit_engine_dashboard(text)


def reset_dashboard():
    """Only call this when you explicitly want new dashboard messages (e.g. new day)."""
    global _engine_msg_id, _market_msg_id
    _engine_msg_id = None
    _market_msg_id = None
    _last_edited.clear()
    _save_state()


# ─────────────────────────────────────────────────────────────────────
# TRADE ENTRY  — EXIT button attached; live-edited while trade is open
# ─────────────────────────────────────────────────────────────────────

def send_trade_entry_with_exit_button(message):
    """Send new trade entry card. Saves message_id so we can live-edit it."""
    global _trade_msg_id
    kb = {"inline_keyboard": [[{"text": "🔴 EXIT NOW", "callback_data": "manual_exit"}]]}
    result = _send(BOT_CHAT_ID, message, reply_markup=kb)
    send_trade_channel(message)
    if result:
        _trade_msg_id = result["message_id"]
        # Invalidate dedup cache so first live-edit always goes through
        _last_edited.pop(_trade_msg_id, None)


def update_trade_live(message: str):
    """Edit the open trade card in-place with latest LTP / PnL. Non-blocking."""
    if not _trade_msg_id:
        return
    _tg_enqueue(_do_update_trade_live, _trade_msg_id, message)


def _do_update_trade_live(expected_msg_id, message: str):
    """Skip stale queued edits after a trade card is deleted or replaced."""
    global _trade_msg_id
    if _trade_msg_id != expected_msg_id:
        return
    result = _edit_with_markup(
        expected_msg_id,
        message,
        {"inline_keyboard": [[{"text": "🔴 EXIT NOW", "callback_data": "manual_exit"}]]},
    )
    if result == _EDIT_GONE and _trade_msg_id == expected_msg_id:
        _trade_msg_id = None
        _last_edited.pop(expected_msg_id, None)


def delete_trade_message():
    """Delete the open trade card when the trade closes."""
    global _trade_msg_id
    if not _trade_msg_id:
        return
    mid = _trade_msg_id
    _trade_msg_id = None
    _last_edited.pop(mid, None)
    try:
        requests.post(
            f"{API_URL}/deleteMessage",
            json={"chat_id": BOT_CHAT_ID, "message_id": mid},
            timeout=10,
        )
    except Exception:
        pass


def remove_exit_button():
    """Legacy — kept for call-site compatibility. Use delete_trade_message() on exit."""
    delete_trade_message()


# ─────────────────────────────────────────────────────────────────────
# SCALP TRADE MESSAGES — entry card (no button), live edit, delete
# ─────────────────────────────────────────────────────────────────────

def send_scalp_entry(message: str):
    """Send scalp entry card. Tracks message_id for live in-place edits."""
    global _scalp_msg_id
    result = _send(BOT_CHAT_ID, message)
    if result:
        _scalp_msg_id = result["message_id"]
        _last_edited.pop(_scalp_msg_id, None)


def update_scalp_live(message: str):
    """Edit the open scalp card in-place with latest LTP / PnL. Non-blocking."""
    if not _scalp_msg_id:
        return
    _tg_enqueue(_do_update_scalp_live, _scalp_msg_id, message)


def _do_update_scalp_live(expected_msg_id, message: str):
    """Skip stale queued edits after a scalp card is deleted or replaced."""
    global _scalp_msg_id
    if _scalp_msg_id != expected_msg_id:
        return
    result = _edit(expected_msg_id, message)
    if result == _EDIT_GONE and _scalp_msg_id == expected_msg_id:
        _scalp_msg_id = None
        _last_edited.pop(expected_msg_id, None)


def delete_scalp_message():
    """Delete the scalp card when the scalp trade closes."""
    global _scalp_msg_id
    if not _scalp_msg_id:
        return
    mid = _scalp_msg_id
    _scalp_msg_id = None
    _last_edited.pop(mid, None)
    try:
        requests.post(
            f"{API_URL}/deleteMessage",
            json={"chat_id": BOT_CHAT_ID, "message_id": mid},
            timeout=10,
        )
    except Exception:
        pass

def repost_engine_dashboard(text: str):
    """Delete the old engine dashboard message and send a fresh one at bottom."""
    _tg_enqueue(_do_repost_engine, text)


def _do_repost_engine(text: str):
    global _engine_msg_id
    # Delete old message silently
    if _engine_msg_id:
        try:
            requests.post(
                f"{API_URL}/deleteMessage",
                json={"chat_id": BOT_CHAT_ID, "message_id": _engine_msg_id},
                timeout=10,
            )
        except Exception:
            pass
        _last_edited.pop(_engine_msg_id, None)
        _engine_msg_id = None
    # Post fresh
    result = _send(BOT_CHAT_ID, text)
    if result:
        _engine_msg_id = result["message_id"]
        _save_state()


# ─────────────────────────────────────────────────────────────────────
# TRADE CONFIRMATION  — YES / SKIP with 3s auto-execute timeout
# ─────────────────────────────────────────────────────────────────────

def ask_trade_permission(side: str, price: float, ml_prob: float,
                         stop: float, target: float) -> bool:
    global _pending_confirm_id, _pending_confirm_resp

    uid = f"confirm_{int(time.time())}"
    _pending_confirm_id   = uid
    _pending_confirm_resp = None

    msg = (
        f"<b>SIGNAL: {side}</b>\n"
        f"Entry ~{price:.1f}  |  ML {ml_prob:.0%}\n"
        f"SL {stop:.1f}  Target {target:.1f}\n"
        f"<i>Auto-execute in 3s</i>"
    )
    kb = {"inline_keyboard": [[
        {"text": "YES — Execute", "callback_data": f"trade_yes_{uid}"},
        {"text": "SKIP",          "callback_data": f"trade_skip_{uid}"},
    ]]}
    _send(BOT_CHAT_ID, msg, reply_markup=kb)

    deadline = time.time() + 3
    while time.time() < deadline:
        # Background thread polls Telegram — just wait for it to set the response
        if _pending_confirm_resp is not None:
            break
        time.sleep(0.3)

    resp = _pending_confirm_resp
    _pending_confirm_id   = None
    _pending_confirm_resp = None
    return resp != "skip"


# ─────────────────────────────────────────────────────────────────────
# UNIFIED COMMAND POLLER
# ─────────────────────────────────────────────────────────────────────

_HELP_TEXT = (
    "<b>Commands</b>\n"
    "/status   — engine snapshot\n"
    "/pause    — stop new entries\n"
    "/resume   — re-enable entries\n"
    "/stop     — halt after current trade\n"
    "/ce 0.65  — override CE threshold\n"
    "/pe 0.68  — override PE threshold\n"
    "/reset    — clear threshold overrides\n"
    "/newdash  — create fresh dashboard messages\n"
    "/help     — this message"
)


def _poll_commands_internal(status_cb=None):
    """Called by background thread — never call directly from engine loop."""
    global _last_update_id, MANUAL_EXIT_REQUESTED, ENGINE_PAUSED
    global ENGINE_STOP_REQUESTED, CE_THRESHOLD_OVERRIDE, PE_THRESHOLD_OVERRIDE
    global _pending_confirm_resp, _poll_fail_count

    try:
        params = {"timeout": 0, "allowed_updates": ["message", "callback_query"]}
        if _last_update_id:
            params["offset"] = _last_update_id + 1

        r = requests.get(GET_UPDATES_URL, params=params, timeout=5)
        data = r.json()
        if not data.get("ok"):
            return

        for update in data.get("result", []):
            _last_update_id = update["update_id"]

            if "callback_query" in update:
                cb     = update["callback_query"]
                uid    = str(cb["from"]["id"])
                cb_id  = cb["id"]
                action = cb.get("data", "")
                _answer_cb(cb_id)

                if uid != AUTHORIZED_USER_ID:
                    continue

                if action == "manual_exit":
                    MANUAL_EXIT_REQUESTED = True
                    send_bot("Manual exit requested.")

                elif action.startswith("trade_yes_"):
                    if _pending_confirm_id and action.endswith(_pending_confirm_id.split("_", 1)[1]):
                        _pending_confirm_resp = "yes"
                        send_bot("Executing trade.")

                elif action.startswith("trade_skip_"):
                    if _pending_confirm_id and action.endswith(_pending_confirm_id.split("_", 1)[1]):
                        _pending_confirm_resp = "skip"
                        send_bot("Signal skipped.")

            elif "message" in update:
                msg  = update["message"]
                uid  = str(msg.get("from", {}).get("id", ""))
                text = msg.get("text", "").strip()

                if uid != AUTHORIZED_USER_ID or not text.startswith("/"):
                    continue

                parts = text.lower().split()
                cmd   = parts[0]

                if cmd == "/pause":
                    ENGINE_PAUSED = True
                    send_bot("Engine PAUSED — no new entries. /resume to restart.")

                elif cmd == "/resume":
                    ENGINE_PAUSED = False
                    send_bot("Engine RESUMED.")

                elif cmd == "/stop":
                    ENGINE_STOP_REQUESTED = True
                    send_bot("Engine STOP after current trade.")

                elif cmd == "/ce" and len(parts) == 2:
                    try:
                        CE_THRESHOLD_OVERRIDE = float(parts[1])
                        send_bot(f"CE threshold override: {CE_THRESHOLD_OVERRIDE:.2f}")
                    except ValueError:
                        send_bot("Usage: /ce 0.65")

                elif cmd == "/pe" and len(parts) == 2:
                    try:
                        PE_THRESHOLD_OVERRIDE = float(parts[1])
                        send_bot(f"PE threshold override: {PE_THRESHOLD_OVERRIDE:.2f}")
                    except ValueError:
                        send_bot("Usage: /pe 0.68")

                elif cmd == "/reset":
                    CE_THRESHOLD_OVERRIDE = None
                    PE_THRESHOLD_OVERRIDE = None
                    send_bot("Threshold overrides cleared.")

                elif cmd == "/newdash":
                    reset_dashboard()
                    send_bot("Dashboard reset — fresh messages will be created next cycle.")

                elif cmd == "/status":
                    cb   = status_cb or _status_callback
                    info = cb() if cb else "Status unavailable."
                    _send(BOT_CHAT_ID, info)

                elif cmd == "/help":
                    send_bot(_HELP_TEXT)

                else:
                    send_bot(f"Unknown: {cmd}\n" + _HELP_TEXT)

    except Exception as e:
        _poll_fail_count += 1
        if _poll_fail_count == 1 or _poll_fail_count % 10 == 0:
            _log.warning("[TG] poll_commands error (#%d): %s", _poll_fail_count, e)
    else:
        _poll_fail_count = 0


_status_callback = None   # set by master_runner so /status works from thread

def poll_commands(status_cb=None):
    """
    Called by engine loop every cycle. Intentionally instant — no network I/O.
    The background thread handles all actual Telegram polling.
    Optionally registers a status callback for /status command.
    """
    global _status_callback
    _ensure_thread()
    if status_cb is not None:
        _status_callback = status_cb


def poll_manual_exit(status_cb=None):
    poll_commands(status_cb=status_cb)


def send_eod_summary(summary: dict):
    """
    Send end-of-day trade summary to bot chat.
    summary dict keys: trades, pnl, wins, losses, avg_win, avg_loss,
                       best, worst, win_rate
    """
    from datetime import date
    t      = summary.get("trades", 0)
    pnl    = summary.get("pnl", 0)
    wins   = summary.get("wins", 0)
    losses = summary.get("losses", 0)
    wr     = summary.get("win_rate", 0)
    avg_w  = summary.get("avg_win", 0)
    avg_l  = summary.get("avg_loss", 0)
    best   = summary.get("best", 0)
    worst  = summary.get("worst", 0)

    pnl_str = f"+{pnl:,.0f}" if pnl >= 0 else f"{pnl:,.0f}"
    status  = "PROFIT DAY" if pnl > 0 else ("BREAK EVEN" if pnl == 0 else "LOSS DAY")

    msg = (
        f"<b>END OF DAY — {date.today().strftime('%d %b %Y')}</b>\n"
        f"<code>━━━━━━━━━━━━━━━━━━━━━━━━</code>\n"
        f"Status    : {status}\n"
        f"Total P&amp;L : <b>₹{pnl_str}</b>\n"
        f"\n"
        f"Trades    : {t}  ({wins}W / {losses}L)\n"
        f"Win Rate  : {wr:.0f}%\n"
        f"Avg Win   : +₹{avg_w:,.0f}\n"
        f"Avg Loss  : ₹{avg_l:,.0f}\n"
        f"Best      : +₹{best:,.0f}\n"
        f"Worst     : ₹{worst:,.0f}\n"
        f"<code>━━━━━━━━━━━━━━━━━━━━━━━━</code>\n"
        f"<i>DRY RUN — no real money</i>"
    )
    _tg_enqueue(_send, BOT_CHAT_ID, msg)
    _tg_enqueue(_send, CHANNEL_ID, msg)
